class Validator{
    constructor(){
        this.validations = [

        ]
    }

    validate(form){
        let input = form.getElementById('input');
        console.log(input);

        let inputArray = [...inputs];
        console.log(inputArray);
    }
}

let form = document.getElementById("register-form");
let submit = document.getElementById("btn-submit");
let Validator = new validator();
// evento

submit.addEventListener('click',function(e) {
    e.preventDefault();

    validator.validate(form);


});