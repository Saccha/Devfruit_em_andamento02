from flask import Flask, redirect,render_template, request
app = Flask(__name__)

#---Produtos---
@app.route("/", methods =["GET"])
def batata ():
	return render_template('index.html')

